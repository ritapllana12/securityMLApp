import { RandomForestRegression as RFRegression } from 'ml-random-forest';

const dataset = [
    [ 1, 2, 1, 1, 37.7749, -122.4194, 120, 840 ],
    [ 1, 2, 0, 2, 40.7128, -74.006, 150, 540 ],
    [ 1, 2, 2, 3, 34.0522, -118.2437, 180, 1320 ],
    [ 1, 2, 0, 4, 41.8781, -87.6298, 240, 360 ],
    [ 1, 2, 1, 1, 27.1145, -102.6789, 100, 720 ],
    [ 1, 2, 0, 2, 30.8239, -88.1207, 120, 1140 ],
    [ 1, 2, 2, 3, 32.1678, -98.4316, 140, 1200 ],
    [ 1, 2, 0, 4, 22.1281, -77.8256, 230, 480 ],
    [ 1, 2, 1, 1, 27.3468, -112.2064, 220, 1080 ],
    [ 1, 2, 0, 2, 30.6896, -64.9867, 120, 960 ],
    [ 1, 2, 2, 3, 24.6623, -126.1007, 150, 720 ],
    [ 1, 2, 0, 4, 31.8681, -97.6102, 120, 900 ]
];

const trainingSet = new Array(dataset.length);
const predictions = new Array(dataset.length);

for (let i = 0; i < dataset.length; ++i) {
  trainingSet[i] = dataset[i].slice(0, 7);
  predictions[i] = dataset[i][7];
}

const options = {
  seed: 7, 
  maxFeatures: 6,
  replacement: false,
  nEstimators: 200
};

const regression = new RFRegression(options);
regression.train(trainingSet, predictions);
const result = regression.predict(trainingSet);
console.log("Resulttt vallaaaa", result);