export function encodeFeatures(data) {
    // Caktojmë një vlerë numerike për çdo kategori të 'os' dhe 'browser'
const osCategories = { 'Windows': 1, 'Linux': 2, 'MacOS': 3 };
const browserCategories = { 'Chrome': 1, 'Firefox': 2, 'Safari': 3, 'Edge': 4 };

// Konvertojmë 'os' dhe 'browser' në vlera numerike
const osValue = osCategories[data[2]] || 0; // Vlera për 'os', 0 nëse nuk gjendet
const browserValue = browserCategories[data[3]] || 0; // Vlera për 'browser', 0 nëse nuk gjendet

// Konvertimi i 'sessionDuration' nga string në sekonda (p.sh., '180s' -> 180)
const sessionDuration = parseInt(data[6].replace('s', '')); // Sesioni në sekonda

// Konvertimi i orës së qasjes '22:00' në minuta nga fillimi i ditës
const [hours, minutes] = data[8].split(':').map(Number);
const accessMinutes = hours * 60 + minutes;

// Kombinimi i të gjitha veçorive në një array të vetëm
return [
    1,                     // Placeholder për username (po e lëmë 1 si shembull)
    2,                     // Placeholder për hashed password (po e lëmë 2 si shembull)
    osValue,               // 'os' e kthyer në numër
    browserValue,          // 'browser' e kthyer në numër
    data[4],               // latitude
    data[5],               // longitude
    sessionDuration,       // sesioni në sekonda
    1,
    accessMinutes          // ora e qasjes në minuta
];
}