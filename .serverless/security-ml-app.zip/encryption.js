import bcrypt from 'bcrypt';

// Function that encrypts the password
export async function encryptPassword(password) {
    const saltRounds = 10;
    if (!password) {
        password = "password";
    }
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    return hashedPassword;
}