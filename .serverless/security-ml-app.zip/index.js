// const { S3Client, GetObjectCommand, PutObjectCommand } = require('@aws-sdk/client-s3');
// const { LambdaClient, InvokeCommand } = require('@aws-sdk/client-lambda');
// const { SNSClient, PublishCommand } = require('@aws-sdk/client-sns');
// const { Readable } = require('stream');

// const s3Client = new S3Client({ region: 'eu-north-1' });
// const lambdaClient = new LambdaClient({ region: 'eu-north-1' });
// const snsClient = new SNSClient({ region: 'eu-north-1' });

// exports.handler = async (event) => {
//     const params = {
//         Bucket: 's3input-bucket',
//         Key: 'data.json'
//     };

//     console.log("params", params);


//     try {
//         // Merr objektin nga S3
//         const data = await s3Client.send(new GetObjectCommand(params));
//         const inputData = await streamToString(data.Body);

//         console.log("inputData", inputData);
        
//         // Ekzekuto modelin ML në Lambda
//         const mlResult = await invokeMLFunction(JSON.parse(inputData));

//         console.log("mlResult", mlResult);

//         // Proceso rezultatet
//         const analysisResult = processMLResult(mlResult);

//         console.log("analysisResult", analysisResult);

//         // Ruaj rezultatet në S3
//         const outputParams = {
//             Bucket: 's3output-bucket',
//             Key: 'result.json',
//             Body: JSON.stringify(analysisResult)
//         };
//         await s3Client.send(new PutObjectCommand(outputParams));

//         console.log("outputParams", outputParams);

//         // Dërgo njoftim në SNS nëse zbulohet një anomali
//         if (analysisResult.anomalyDetected) {
//             await triggerSecurityAlarm(analysisResult);
//         }

//         return {
//             statusCode: 200,
//             body: JSON.stringify('Analiza përfundoi me sukses!')
//         };
//     } catch (error) {
//         console.error('Error:', error);
//         return {
//             statusCode: 500,
//             body: JSON.stringify('Gabim gjatë analizës!')
//         };
//     }
// };

// // Funksion për të ekzekutuar modelin ML në Lambda
// async function invokeMLFunction(data) {
//     const params = {
//         FunctionName: 'my-ml-lambda-function',
//         Payload: Buffer.from(JSON.stringify(data))
//     };

//     const response = await lambdaClient.send(new InvokeCommand(params));
//     return JSON.parse(Buffer.from(response.Payload).toString());
// }

// // Funksion për të procesuar rezultatet e ML
// function processMLResult(mlResult) {
//     return {
//         anomalyDetected: mlResult.anomalyScore > 0.7,
//         details: mlResult
//     };
// }

// // Funksion për të dërguar njoftim në SNS
// async function triggerSecurityAlarm(analysisResult) {
//     const alarmParams = {
//         Message: `Anomali e zbuluar! Detajet: ${JSON.stringify(analysisResult)}`,
//         TopicArn: 'arn:aws:sns:region:account-id:my-security-topic'
//     };

//     await snsClient.send(new PublishCommand(alarmParams));
// }

// // Funksion ndihmës për të kthyer një stream në string
// async function streamToString(stream) {
//     return new Promise((resolve, reject) => {
//         const chunks = [];
//         stream.on('data', (chunk) => chunks.push(chunk));
//         stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf-8')));
//         stream.on('error', reject);
//     });
// }

// exports.handler();