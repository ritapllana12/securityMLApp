declare module 'ml-logistic-regression';
