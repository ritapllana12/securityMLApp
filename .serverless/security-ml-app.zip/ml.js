// const { S3Client, GetObjectCommand, PutObjectCommand } = require('@aws-sdk/client-s3');
// const mlRegression = require('ml-regression');
// const LinearRegression = mlRegression.LinearRegression;

// // Krijo një klient S3
// const s3Client = new S3Client({ region: 'eu-north-1' });

// const inputBucket = 's3input-bucket';
// const outputBucket = 's3output-bucket';

// // Funksion për të ngarkuar të dhëna nga S3
// async function loadDataFromS3(key) {
//     const params = { Bucket: inputBucket, Key: key };
//     const command = new GetObjectCommand(params);  // Përdorim GetObjectCommand
//     const data = await s3Client.send(command);  // Përdorim klientin s3Client për të dërguar komandën
//     const bodyContents = await streamToString(data.Body);  // Lexojmë përmbajtjen
//     return JSON.parse(bodyContents);  // Kthejmë të dhënat e parsuar
// }

// // Funksion për të kthyer stream në string
// const streamToString = (stream) =>
//     new Promise((resolve, reject) => {
//         const chunks = [];
//         stream.on('data', (chunk) => chunks.push(chunk));
//         stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
//         stream.on('error', reject);
//     });

// exports.handler = async (event) => {
//     try {
//         // Ngarkojmë të dhënat e trajnimit
//         const trainingData = await loadDataFromS3('training-data.json');
//         const { X, y } = trainingData;

//         // Trajnojmë modelin LinearRegression
//         const regression = new LinearRegression(X, y);
//         console.log('Model trained:', regression.toString());

//         // Ngarkojmë të dhënat për inference
//         const inferenceData = await loadDataFromS3('inference-data.json');
//         const predictions = inferenceData.map(input => regression.predict(input));

//         // Ruajmë rezultatet në S3
//         const outputParams = {
//             Bucket: outputBucket,
//             Key: 'result.json',
//             Body: JSON.stringify({ predictions }),
//             ContentType: 'application/json'
//         };
//         const putCommand = new PutObjectCommand(outputParams);  // Përdorim PutObjectCommand
//         await s3Client.send(putCommand);  // Dërgojmë komandën për ruajtjen e rezultateve
//         console.log('Prediction results saved to S3');

//         return {
//             statusCode: 200,
//             body: JSON.stringify({ message: 'Predictions completed and saved to S3.' })
//         };

//     } catch (error) {
//         console.error('Error:', error);
//         return {
//             statusCode: 500,
//             body: JSON.stringify({ message: 'Error occurred during predictions.', error: error.message })
//         };
//     }
// };

// exports.handler();